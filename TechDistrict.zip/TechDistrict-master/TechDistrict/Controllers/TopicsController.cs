﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TechDistrict.Models;
using TechDistrict.ViewModels;
using PagedList;
using Microsoft.AspNet.Identity;

namespace TechDistrict.Controllers
{
    public class TopicsController : Controller
    {
        public ApplicationDbContext db = new ApplicationDbContext();
        // GET: Topics
        public ViewResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var topics = from s in db.Topics
                           select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                topics = topics.Where(s => s.Title.Contains(searchString)
                                       || s.Content.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "name_desc":
                    topics = topics.OrderByDescending(s => s.Title);
                    break;
                case "Date":
                    topics = topics.OrderBy(s => s.PostingTime);
                    break;
                case "date_desc":
                    topics = topics.OrderByDescending(s => s.PostingTime);
                    break;
                default:
                    topics = topics.OrderBy(s => s.Title);
                    break;
            }
            int pageSize = 5;
            int pageNumber = (page ?? 1);
            //var ViewModels = new TopicsViewModel()
            //{
            //    Topics = topics.ToPagedList(pageNumber,pageSize),
            //};
            return View(topics.ToPagedList(pageNumber, pageSize));
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult New()
        {
            var categorii = db.Categories.ToList();
            var viewmodel = new TopicCategories()
            {
                categories = categorii,
            };
            return View(viewmodel);
        }

        [HttpPost]
        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Create(Topic topic)
        {
            if (topic.Title != "" && topic.Content != "" && topic.CategoryId != 0)
            {
                topic.PostingTime = System.DateTime.Now;
                topic.UserId = User.Identity.GetUserId();
                db.Topics.Add(topic);
                db.SaveChanges();
                return RedirectToAction("Index", "Topics");
            }
            else
            {
                return RedirectToAction("New", "Topics");
            }
        }

        [HttpPost]
        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Update(Topic topic)
        {
            var topicInDB = db.Topics.Single(c => c.Id == topic.Id);
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Show", "Topics", new { id = topicInDB.Id });
            }
            topicInDB.Title = topic.Title;
            topicInDB.Content = topic.Content;
            topicInDB.CategoryId = topic.CategoryId;
            db.SaveChanges();
            return RedirectToAction("Show", "Topics", new { id = topicInDB.Id });
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Topic topic = db.Topics.Find(id);
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Edit", "Topics", new { id = id });
            }
            if (topic == null)
            {
                return HttpNotFound();
            }
            if (topic.UserId == User.Identity.GetUserId() || User.IsInRole("Administrator"))
            {
                var viewModel = new TopicCategories()
                {
                    categories = db.Categories.ToList(),
                    topic = topic,
                };
                return View(viewModel);
            }
            else
            {
                TempData["message"] = "Nu aveti dreptul sa faceti modificari asupra unui articol care nu va apartine!";
                return RedirectToAction("Index");
            }
        }
    

    public ActionResult Show(int Id)
        {
            var topic1 = db.Topics.SingleOrDefault(c => c.Id == Id);
            IQueryable<Comment> commentsDbSet = db.Comments;
            commentsDbSet = commentsDbSet.Where(z => z.articleID == Id);

            List<Comment> comments1 = commentsDbSet.OrderBy(s => s.Id).ToList();
            
            var viewModel = new TopicComments
            {
                topic = topic1,
                comments = comments1,
                modelComment = new Comment
                {
                    articleID = Id,
                }
            };
            return View(viewModel);
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Delete(int id)
        {
                Topic topic = db.Topics.Find(id);
                if (topic.UserId == User.Identity.GetUserId() || User.IsInRole("Administrator") || User.IsInRole("Moderator"))
                {
                    db.Topics.Remove(topic);
                    db.SaveChanges();
                    TempData["stergere"] = "Discutia a fost stersa cu succes";
                    return RedirectToAction("Index");
                }
                else
                {
                    TempData["stergereEroare"] = "Nu aveti dreptul sa stergeti discutia";
                    return RedirectToAction("Index");
            }
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult ShowByCategory(int id)
        {
            IQueryable < Topic > topics = from s in db.Topics
                         select s;
            
            topics = topics.Where(c => c.CategoryId == id);

            return View(topics.ToList());
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult MyTopics()
        {
            IQueryable<Topic> topics = from s in db.Topics
                                       select s;

            var userCurent = User.Identity.GetUserId();

            topics = topics.Where(c => c.UserId == userCurent);

            return View(topics.ToList());
        }

    }
}