﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TechDistrict.Models;

namespace TechDistrict.Controllers
{
    public class CommentsController : Controller
    {
        public ApplicationDbContext db = new ApplicationDbContext();
        // GET: Comments
        public ActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult New(int Id)
        {
            var newComment = new Comment();
            newComment.articleID = Id;
            return View(newComment);
        }

        [HttpPost]
        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Create(Comment comment, int Id)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Show", "Topics", new { Id = comment.articleID });
            }
            comment.PostingTime = System.DateTime.Now;
            comment.UserId = User.Identity.GetUserId();
            comment.articleID = Id;
            db.Comments.Add(comment);
            db.SaveChanges();
            return RedirectToAction("Show", "Topics", new { Id = comment.articleID });
        }

        [HttpPost]
        [Authorize]
        public ActionResult Update(Comment comment)
        {

            if (!ModelState.IsValid)
            {
                return RedirectToAction("Show", "Topics", new { Id = comment.articleID });
            }

            var commentInDB = db.Comments.Single(c => c.Id == comment.Id);
            commentInDB.Content = comment.Content;
            db.SaveChanges();
            return RedirectToAction("Show", "Topics", new { Id = commentInDB.articleID });
        }

        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            if (comment.UserId == User.Identity.GetUserId() || User.IsInRole("Administrator") || User.IsInRole("Moderator"))
            {
                return View(comment);
            }
            else
            {
                TempData["message"] = "Nu aveti dreptul sa faceti modificari asupra unui comentariu care nu va apartine!";
                return RedirectToAction("Index","Topics");
            }
        }

        [Authorize(Roles = "Utilizator,Moderator,Administrator")]
        public ActionResult Delete(int id)
        {
            Comment comment = db.Comments.Find(id);
            if (comment.UserId == User.Identity.GetUserId() || User.IsInRole("Administrator") || User.IsInRole("Moderator"))
            {
                db.Comments.Remove(comment);
                db.SaveChanges();
                TempData["stergere"] = "Comentariul a fost sters cu succes";
                return RedirectToAction("Show", "Topics", new { id = comment.articleID });
            }
            else
            {
                TempData["stergereEroare"] = "Nu aveti dreptul sa stergeti comentariul";
                return RedirectToAction("Show", "Topics", new { id = comment.articleID });
            }  
            
        }
    }
}