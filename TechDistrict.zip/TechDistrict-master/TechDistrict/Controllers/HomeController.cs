﻿using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechDistrict.Models;

namespace TechDistrict.Controllers
{
    public class HomeController : Controller
    {
        public ApplicationDbContext db = new ApplicationDbContext();

        public ViewResult Index(string sortOrder, string currentFilter, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";

            var topics = from s in db.Topics
                         select s;
            
            switch (sortOrder)
            {
                case "name_desc":
                    topics = topics.OrderByDescending(s => s.Title);
                    break;
                case "Date":
                    topics = topics.OrderBy(s => s.PostingTime);
                    break;
                case "date_desc":
                    topics = topics.OrderByDescending(s => s.PostingTime);
                    break;
                default:
                    topics = topics.OrderByDescending(s => s.PostingTime);
                    break;
            }
            int pageSize = 5;
            int pageNumber = (page ?? 1);
            return View(topics.ToPagedList(pageNumber, pageSize));
        }

    }
}