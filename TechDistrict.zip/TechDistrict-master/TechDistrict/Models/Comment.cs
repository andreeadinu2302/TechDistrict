﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TechDistrict.Models
{
    public class Comment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int articleID { get; set; }

        [Required(ErrorMessage = "Comentariul nu poate fi gol")]
        [Display(Name = "Lasati un comentariu")]
        public string Content { get; set; }

        public DateTime PostingTime { get; set; }

        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
    }
}