﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TechDistrict.Models
{
    public class Topic
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Titlul postarii este obligatoriu")]
        [StringLength(255)]
        [Display(Name ="Titilul postarii")]
        public string Title { get; set; }

        [Display(Name = "Categorie")]
        [Required(ErrorMessage = "Topic-ul trebuie sa aiba o categorie")]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        [Display(Name = "Categorie")]
        public virtual Category Categories { get; set; }

        [Required(ErrorMessage = "Topic-ul trebuie sa aiba continut")]
        [Display(Name = "Continut Postare")]
        public string Content { get; set; }
        
        public DateTime PostingTime { get; set; }

        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
    }
}