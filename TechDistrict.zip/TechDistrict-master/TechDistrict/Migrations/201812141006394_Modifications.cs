namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Modifications : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Topics", "Categorie_Id", "dbo.Categories");
            DropIndex("dbo.Topics", new[] { "Categorie_Id" });
            RenameColumn(table: "dbo.Topics", name: "Categorie_Id", newName: "CategoryId");
            AlterColumn("dbo.Topics", "CategoryId", c => c.Int(nullable: false));
            CreateIndex("dbo.Topics", "CategoryId");
            AddForeignKey("dbo.Topics", "CategoryId", "dbo.Categories", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Topics", "CategoryId", "dbo.Categories");
            DropIndex("dbo.Topics", new[] { "CategoryId" });
            AlterColumn("dbo.Topics", "CategoryId", c => c.Int());
            RenameColumn(table: "dbo.Topics", name: "CategoryId", newName: "Categorie_Id");
            CreateIndex("dbo.Topics", "Categorie_Id");
            AddForeignKey("dbo.Topics", "Categorie_Id", "dbo.Categories", "Id");
        }
    }
}
