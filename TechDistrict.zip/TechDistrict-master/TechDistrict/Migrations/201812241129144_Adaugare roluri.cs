namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Adaugareroluri : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Topics", "UserId", c => c.String(maxLength: 128));
            CreateIndex("dbo.Topics", "UserId");
            AddForeignKey("dbo.Topics", "UserId", "dbo.AspNetUsers", "Id");
            DropColumn("dbo.Topics", "User");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Topics", "User", c => c.String());
            DropForeignKey("dbo.Topics", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.Topics", new[] { "UserId" });
            DropColumn("dbo.Topics", "UserId");
        }
    }
}
