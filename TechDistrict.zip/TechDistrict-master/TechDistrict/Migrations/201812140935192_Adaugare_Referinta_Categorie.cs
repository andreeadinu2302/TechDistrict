namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Adaugare_Referinta_Categorie : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Topics", "CategoryId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Topics", "CategoryId");
        }
    }
}
