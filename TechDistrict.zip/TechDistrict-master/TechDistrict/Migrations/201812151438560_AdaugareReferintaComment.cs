namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AdaugareReferintaComment : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Comments", "articleId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Comments", "articleId");
        }
    }
}
