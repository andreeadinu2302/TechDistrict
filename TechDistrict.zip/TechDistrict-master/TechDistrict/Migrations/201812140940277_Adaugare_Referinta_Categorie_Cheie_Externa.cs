namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Adaugare_Referinta_Categorie_Cheie_Externa : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Topics", "Categorie_Id", c => c.Int());
            CreateIndex("dbo.Topics", "Categorie_Id");
            AddForeignKey("dbo.Topics", "Categorie_Id", "dbo.Categories", "Id");
            DropColumn("dbo.Topics", "CategoryId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Topics", "CategoryId", c => c.Int(nullable: false));
            DropForeignKey("dbo.Topics", "Categorie_Id", "dbo.Categories");
            DropIndex("dbo.Topics", new[] { "Categorie_Id" });
            DropColumn("dbo.Topics", "Categorie_Id");
        }
    }
}
