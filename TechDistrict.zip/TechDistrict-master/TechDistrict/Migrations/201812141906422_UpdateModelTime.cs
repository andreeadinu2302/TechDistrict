namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateModelTime : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Topics", "PostingTime", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Topics", "PostingTime");
        }
    }
}
