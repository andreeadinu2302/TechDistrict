namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateConstraintsInModels : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Categories", "Name", c => c.String(nullable: false, maxLength: 100));
            AlterColumn("dbo.Topics", "Title", c => c.String(nullable: false, maxLength: 255));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Topics", "Title", c => c.String());
            AlterColumn("dbo.Categories", "Name", c => c.String());
        }
    }
}
