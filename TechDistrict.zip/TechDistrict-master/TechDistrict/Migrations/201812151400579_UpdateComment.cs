namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateComment : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Comments", "PostingTime", c => c.DateTime(nullable: false));
            AddColumn("dbo.Comments", "User", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Comments", "User");
            DropColumn("dbo.Comments", "PostingTime");
        }
    }
}
