namespace TechDistrict.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateUserPropertyTopic : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Topics", "User", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Topics", "User");
        }
    }
}
