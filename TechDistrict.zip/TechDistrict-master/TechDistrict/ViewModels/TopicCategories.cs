﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TechDistrict.Models;

namespace TechDistrict.ViewModels
{
    public class TopicCategories
    {
        public Topic topic { get; set; }
        public List<Category> categories { get; set; }
    }
}