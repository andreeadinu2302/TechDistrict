﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TechDistrict.Models;

namespace TechDistrict.ViewModels
{
    public class TopicsViewModel
    {
        public List<Topic> Topics { get; set; }
    }
}