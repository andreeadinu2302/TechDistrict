﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TechDistrict.Models;

namespace TechDistrict.ViewModels
{
    public class TopicComments
    {
        public Topic topic { get; set; }
        public Comment modelComment { get; set; }
        public List<Comment> comments { get; set; }
    }
}