# TechDistrict
A tech forum based on asp.net MVC 5

Published to <a href="https://techdistrict.azurewebsites.net">TechDistrict Forum</a>
